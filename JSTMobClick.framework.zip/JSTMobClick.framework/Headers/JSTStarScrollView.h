//
//  JSTStarScrollView.h
//  JSTMobClick
//
//  Created by 01 on 16/9/19.
//  Copyright © 2016年 Czj. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JSTStarScrollView : UIScrollView

- (void) createContent:(void(^)())end;

@end
