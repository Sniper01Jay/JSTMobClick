//
//  JSTStartView.h
//  JSTMobClick
//
//  Created by 01 on 16/9/20.
//  Copyright © 2016年 Czj. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JSTStartView : UIView

- (void) createContent:(void(^)())end;

@end
