//
//  JSTStartViewController.h
//  JSTMobClick
//
//  Created by 01 on 16/9/19.
//  Copyright © 2016年 Czj. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JSTStartViewController : UIViewController

- (void) createContent:(void(^)())end;

@end
